<option value="0">{{ translate('No Parent') }}</option>
@foreach ($categories as $category)
    <option value="{{ $category->id }}">{{ $category->name }}</option>
    @foreach ($category->childrenCategories()->when(isset($id),function ($q,$v){
        $q->where("id","<>",$id);
    })->get() as $childCategory)
        @if(isset($id))
            @include('categories.child_category', ['child_category' => $childCategory,"id" => $id])
        @else
            @include('categories.child_category', ['child_category' => $childCategory])
        @endif
    @endforeach
@endforeach
