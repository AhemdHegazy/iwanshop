<?php

return[
    "Options" => "الخيارات ",
    "Questions" => " الأسئلة",
    "Current Version" => "النسخة الحالية",
    "Update your system" => "تحديث النظام",
    "Check Here" => "تأكد من هنا ",
    "Update Now" => "حدث الآن ",
    "Please turn off maintenance mode before updating." => "يرجى  تشغيل وضع الصيانة قبل التحديث.",
    "If you are using any addon make sure to update those addons after updating." => "إذا كنت تستخدم أي أداة إضافية ، فتأكد من تحديث هذه الوظائف الإضافية بعد التحديث.",
    "Upload that zip file here and click update now." => "قم بتحميل هذا  الملف المضغوط هنا وانقر فوق تحديث الآن.",
    "Extract downloaded zip. You will find updates.zip file in those extrace files." => "استخراج ملف zip الذي تم تنزيله. ستجد ملف updates.zip في ملفات الاستخراج تلك.",
    "Make sure your server has matched with all requirements." => "تأكد من تطابق  الخاص بك مع جميع المتطلبات.",
];
